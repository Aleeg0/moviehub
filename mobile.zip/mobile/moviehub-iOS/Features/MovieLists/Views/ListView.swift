//
//  ListView.swift
//  moviehub-iOS
//
//  Created by Pavel Playerz0redd on 19.04.26.
//

import Foundation
import SwiftUI
import Kingfisher

struct ListView: View {
    private let movies: [MovieListModel]
    
    init(movies: [MovieListModel]) {
        self.movies = movies
    }
    
    var body: some View {
        ScrollView(showsIndicators: false) {
            LazyVStack(spacing: 10) {
                ForEach(movies, id: \.self) { movie in
                    movieView(movie: movie)
                }
            }
        }
    }
}

private extension ListView {
    func movieView(movie: MovieListModel) -> some View {
        HStack(alignment: .top, spacing: 10) {
            posterView(posterPath: movie.posterPath)
            
            movieInfoView(movie: movie)
            
            Spacer()
        }
        .frame(maxWidth: .infinity)
        .padding(10)
        .background {
            RoundedRectangle(cornerRadius: 20)
                .foregroundStyle(.achievementGray)
        }
    }
    
    func movieInfoView(movie: MovieListModel) -> some View {
        VStack(alignment: .leading, spacing: 7) {
            Text(movie.title)
                .font(.system(size: 23, weight: .semibold))
                .foregroundStyle(.white)
            
            HStack {
                ratingView(rating: movie.voteAverage)
                
                Text(String(Calendar.current.component(.year, from: movie.releaseDate)))
                    .font(.system(size: 17, weight: .regular))
                    .foregroundStyle(.white)
            }
            
            Text("\(movie.genreId)")
                .font(.system(size: 17, weight: .regular))
                .foregroundStyle(.white)
        }
    }
    
    func ratingView(rating: Double) -> some View {
        HStack(spacing: 3) {
            Image(systemName: "star.fill")
                .font(.system(size: 22))
            
            Text("\(rating, specifier: "%.1f")")
                .font(.system(size: 17, weight: .semibold))
        }
        .foregroundStyle(.yellow)
        .padding(6)
        .background {
            Capsule()
                .foregroundStyle(.yellow.opacity(0.6))
        }
    }
    
    func posterView(posterPath: String) -> some View {
        KFImage(URL(string: "https://image.tmdb.org/t/p/original" + posterPath))
            .resizable()
            .frame(width: 160, height: 200)
            .scaledToFill()
            .clipShape(.rect(cornerRadius: 20))
    }
}
