//
//  MovieListModel.swift
//  moviehub-iOS
//
//  Created by Pavel Playerz0redd on 19.04.26.
//

import Foundation

struct MovieListModel: Hashable, Equatable {
    let id: Int
    let title: String
    let genreId: Int
    let posterPath: String
    let releaseDate: Date
    let voteAverage: Double
    
    let status: WatchStatus
    
    enum WatchStatus: String, Decodable {
        case liked
        case disliked
        case viewed
    }
}

extension MovieListModel {
    init(from dto: MovieListDTO) {
        self.id = dto.id
        self.genreId = dto.genreId
        self.posterPath = dto.posterPath
        self.releaseDate = dto.releaseDate
        self.title = dto.title
        self.voteAverage = dto.voteAverage
        self.status = .init(from: dto.status)
    }
}

extension MovieListModel.WatchStatus {
    init(from dto: MovieListDTO.WatchStatus) {
        self = switch dto {
        case .liked:
                .liked
        case .disliked:
                .disliked
        case .viewed:
                .viewed
        }
    }
}
