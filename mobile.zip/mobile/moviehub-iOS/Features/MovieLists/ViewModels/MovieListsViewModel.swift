//
//  MovieListsViewModel.swift
//  moviehub-iOS
//
//  Created by Pavel Playerz0redd on 19.04.26.
//

import Foundation
import Combine

@MainActor
final class MovieListsViewModel: ObservableObject {
    
    @Published var selectedTab: Tabs = .liked
    @Published var films: [MovieListModel] = []
    @Published var viewState: ViewState = .loading
    
    private let movieListProvider: UserListFilmProviderProtocol = UserListFilmProvider(networkManager: NetworkManager(), privateStorage: UserDefaultsStorageManager(), decoder: DecodeManager())
    
    func fetchFilms() {
        Task {
            let movies = try await movieListProvider.fetchUserFilms()
//            await MainActor.run {
//                self.films = movies
//            }
        }
        self.viewState = .success
    }
}


extension MovieListsViewModel {
    enum Tabs: CaseIterable, Hashable {
        case liked
        case disliked
        case watched
        
        var image: String {
            switch self {
            case .liked:
                "heart.circle"
            case .disliked:
                "heart.slash.circle"
            case .watched:
                "eyes.inverse"
            }
        }
    }
}
