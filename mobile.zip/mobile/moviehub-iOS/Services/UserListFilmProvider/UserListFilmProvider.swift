//
//  UserListFilmProvider.swift
//  moviehub-iOS
//
//  Created by Pavel Playerz0redd on 19.04.26.
//

import Foundation
import Kingfisher

protocol UserListFilmProviderProtocol {
    func fetchUserFilms() async throws -> [MovieListModel]
}

final class UserListFilmProvider: UserListFilmProviderProtocol {
    
    private let networkManager: INetworkManager
    private let privateStorage: IPrivateManager
    private let decoder: IDecodeManager
    
    private var prefetcher: ImagePrefetcher?
    
    init(networkManager: INetworkManager, privateStorage: IPrivateManager, decoder: IDecodeManager) {
        self.networkManager = networkManager
        self.privateStorage = privateStorage
        self.decoder = decoder
    }
    
    func fetchUserFilms() async throws -> [MovieListModel] {
        guard let token: String = privateStorage.fetch(key: "accessToken") else { return [] }
        guard let data = try await networkManager.sendRequest(endpoint: MovieListsEndpoints.allMovies, body: nil, authorization: .bearer(token: token)) else { return [] }
        
        if let movies: [MovieListDTO] = decoder.decode(data: data) {
            let urls: [URL] = movies.compactMap( { URL(string: $0.posterPath) } )
            //prefetchImages(urls: urls)
            return movies.map( { MovieListModel(from: $0) } )
        } else {
            return []
        }
    }
    
    private func prefetchImages(urls: [URL]) {
        self.prefetcher?.stop()
        let prefetcher = ImagePrefetcher(urls: urls)
        prefetcher.start()
        self.prefetcher = prefetcher
    }
}
